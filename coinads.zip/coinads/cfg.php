<?php


$cookie="PHPSESSID=46bae36c8d796118b4bac1ded3158bdb;_ga=GA1.2.1146196115.1637809782;_gid=GA1.2.382591960.1637809782;bitmedia_fid=eyJmaWQiOiJjMDllZmNkNGU0YTMyMmM4MWI3MjU3OTdmYzlmMmVmYiIsImZpZG5vdWEiOiJhOWM3ZGNhNzAxNjVkNWE1MzViODM5ODI1ZjkzNDg4ZSJ9;AccExist=200326;SesHashKey=l3mnxpdd1rjswxn1;SesToken=ses_id%3D200326%26ses_key%3Dl3mnxpdd1rjswxn1;cf_clearance=MCQetdvF1gz1zMQTehgcBEVdpwdz0NW8hN16Z177eiA-1637821644-0-250;_gat_gtag_UA_116201299_15=1";

$url_solve="https://api-secure.solvemedia.com/papi/_challenge.js?k=P7UUEs9AZZuZ1GtxoHnRsTutaLGvyb26;f=_ACPuzzleUtil.callbacks%5B0%5D;l=en;t=img;s=standard;c=js,h5c,h5ct,svg,h5v,v/h264,v/webm,h5a,a/mp3,a/ogg,ua/chrome,ua/chrome81,os/android,os/android10,fwv/Betmxw.tamv47,jslib/jquery,htmlplus;am=lupzjrHDfEWTAcMOscN8RQ;ca=ajax;ts=1637745314;ct=1637799141;th=white;r=0.40862390559756934";

?>
