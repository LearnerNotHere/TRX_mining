<?php
$res="\033[0m";
$abu2="\033[1;30m";
$putih="\033[0;37m";
$putih2="\033[1;37m";
$red="\033[0;31m";
$red2="\033[1;31m";
$green="\033[0;32m";
$green2="\033[1;32m";
$yellow="\033[0;33m";
$yellow2="\033[1;33m";
$blue="\033[0;34m";
$blue2="\033[1;34m";
$purple="\033[0;35m";
$purple2="\033[1;35m";
system("clear");
error_reporting(0);
class CoinAds{
 
 public function msg($str){
  echo $str;
 }
 public function jeda(){
  return usleep(500000);
 }
 public function rm(){
  return "\r                         \r";
 }
  public function pars($awal,$akhir,$inti,$res){
   $a=explode($awal,$res);
   $b=explode($akhir,$a[$inti]);
   return $b[0];
  }
   public function curl($url, $post=0){
	include"cfg.php";
          $ch = curl_init();
          curl_setopt($ch, CURLOPT_URL, $url);
          curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
          curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
          curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
          curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
          curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 30);
          curl_setopt($ch, CURLOPT_TIMEOUT, 60);
          if($post){
          curl_setopt($ch, CURLOPT_POST, true);
          curl_setopt($ch, CURLOPT_POSTFIELDS, $post);}
       	  $headers=array();
	  $headers[]="Host: coinadster.com";
	  $headers[]="accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng;q=0.8,application/signed-exchange;v=b3;q=0.9";
	  $headers[]="User-Agent: Mozilla/5.0 (Linux; Android 10; CPH1819 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/81.0.4044.138 Mobile Safari/537.36";
	  $headers[]="cookie: ".$cookie;
	  $headers[]="accept-language: id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7";
      	curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
      return curl_exec($ch);
   }
public function solve($url){
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 30);
        curl_setopt($ch, CURLOPT_TIMEOUT, 60);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "GET");
        $header=array();
        $header[]="Host: api-secure.solvemedia.com";
        $header[]="user-agent: Mozilla/5.0 (Linux; Android 10; CPH1819 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/81.0.4044.138 Mobile Safari/537.36";
        $header[]="referer: https://coinadster.com/";
	curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
	curl_setopt($ch, CURLOPT_TIMEOUT, 60);
	$result = curl_exec($ch);
	curl_close($ch);
	return $result;
}
public function page(){
 return $this->curl("https://coinadster.com/faucet.html");
}

public function api(){
	$api=["7fedfeb81d88957","7778b953c988957","5f9f2e64c788957","dcbec5006d88957","92379eaa2288957","e4b480f1c488957","8e0899a40088957","7cd0129c6f88957","361876dd6388957","0bb911f50b88957"];
	$r=rand(0,9);
      return $api[$r];
}

public function ajax($token,$challenge,$hasil){
 return $this->curl("https://coinadster.com/system/ajax.php","a=getFaucet&token=".$token."&captcha=0&challenge=".$challenge."&response=".$hasil);
}
public function challenge($challenge){
        return $this->solve("https://api-secure.solvemedia.com/papi/media?c={$challenge};w=300;h=150;fg=000000;bg=f8f8f8");
        }

 public function timer($tmr){
    $timr=time()+$tmr;
    while(true):
    echo "\r                       \r";
    $res = $timr-time();
    if($res < 1){
    break;
    }
    echo date('H:i:s',$res);
    sleep(1);
    endwhile;
   }}


 $new=new CoinAds();
include"cfg.php";
$nama=$new->pars('<font class="text-success">','</font><br />',1,$new->page());
$balance=$new->pars('<div class="text-primary"><b>','</b></div></div>',1,$new->page());

echo $blue."\n╔══════════════════════════╗";
echo $blue."\n║".$putih."██████████████████████████".$blue."║";
echo $blue."\n║".$putih."█".$blue."╔═════╗".$putih."███████████████⊙██".$blue."║";
echo $blue."\n║".$putih."█".$blue."║".$yellow."NOKIA".$blue."║".$putih."██████████████████".$blue."║".$putih." = = = = = = = = = = = = = = = =";
echo $blue."\n║".$putih."█".$blue."╚═════╝".$putih."██████████████████".$blue."║".$putih2." [!] CREATOR : MRs.M4JOR.exe";
echo $blue."\n║".$putih."██████████████████████████".$blue."║".$putih2." [!] WHATSAPP : 081327753909";
echo $blue."\n║".$putih."█".$blue."╔══════════════════════╗".$putih."█".$blue."║ ".$putih2."[!] JOIN GRUP : t.me/panggilmajor";
echo $blue."\n║".$putih."█".$blue."║".$yellow."XL".$abu2."▒▒▒▒▒▒▒▒▒▒".$putih2."📶4G".$abu2."▒▒".$putih2."100%".$blue."║".$putih."█".$blue."║ ".$putih2."[#] VERSI : 2.0";
echo $blue."\n║".$putih."█".$blue."║".$abu2."▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒".$blue."║".$putih."█".$blue."║".$putih." = = = = = = = = = = = = = = = =";
echo $blue."\n║".$putih."█".$blue."║".$abu2."▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒".$blue."║".$putih."█".$blue."║".$putih." = = = = = = = = = = = = = = = =";
echo $blue."\n║".$putih."█".$blue."║".$putih2."WELCOME TO SCRIPT ".$abu2."▒▒▒▒".$blue."║".$putih."█".$blue."║".$red." [!] warning !!";
echo $blue."\n║".$putih."█".$blue."║".$abu2."▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒".$blue."║".$putih."█".$blue."║".$yellow." [-] ini adalah program ilegal";
echo $blue."\n║".$putih."█".$blue."║".$putih2."BY MR.MAJOR  ".$abu2."▒▒▒▒▒▒▒▒▒".$blue."║".$putih."█".$blue."║".$yellow." [-] https://saweria.co/Mrmajor";
echo $blue."\n║".$putih."█".$blue."║".$abu2."▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒".$blue."║".$putih."█".$blue."║".$putih." = = = = = = = = = = = = = = = =";
echo $blue."\n║".$putih."█".$blue."║".$putih2."----------".$abu2."▒▒▒▒▒▒▒▒▒▒▒▒".$blue."║".$putih."█".$blue."║";
echo $blue."\n║".$putih."█".$blue."║".$abu2."▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒".$blue."║".$putih."█".$blue."║".$green2." [#] SCRIPT: coinads";
echo $blue."\n║".$putih."█".$blue."║".$abu2."▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒".$blue."║".$putih."█".$blue."║";
echo $blue."\n║".$putih."█".$blue."║".$abu2."▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒".$blue."║".$putih."█".$blue."║".$putih." = = = = = = = = = = = = = = = =";
echo $blue."\n║".$putih."█".$blue."║".$abu2."▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒".$blue."║".$putih."█".$blue."║".$green2." [#] nickname {$putih2}={$red2}> ".$putih2.$nama;
echo $blue."\n║".$putih."█".$blue."║".$abu2."▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒".$blue."║".$putih."█".$blue."║".$green2." [$] balance {$putih2} ={$red2}> ".$putih2.$balance;
echo $blue."\n║".$putih."█".$blue."║".$abu2."▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒".$blue."║".$putih."█".$blue."║".$putih." = = = = = = = = = = = = = = = =";
echo $blue."\n║".$putih."█".$blue."║".$abu2."▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒".$blue."║".$putih."█".$blue."║";
echo $blue."\n║".$putih."█".$blue."║".$abu2."▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒".$blue."║".$putih."█".$blue."║";
echo $blue."\n║".$putih."█".$blue."║".$putih2."KEMBALI".$abu2."▒▒▒▒▒▒▒▒▒▒".$putih2."PILIH".$blue."║".$putih."█".$blue."║";
echo $blue."\n║".$putih."█".$blue."╚══════════════════════╝".$putih."█".$blue."║";
echo $blue."\n║".$putih."██████████████████████████".$blue."║";
echo $blue."\n║".$putih."███▤▤▤▤▤██▧▧▧▧▧▧██▤▤▤▤▤███".$blue."║";
echo $blue."\n║".$putih."██████████████████████████".$blue."║";
echo $blue."\n╚══════════════════════════╝\n";


 while(true){
  ulang:
 $page=$new->page();
 echo $putih2;
 echo $new->msg("mengambil token").$new->jeda().$new->rm();
 $token=$new->pars("var token = '","';",1,$page);
 echo $new->msg("mengambil challenge").$new->jeda().$new->rm();

$api=array("7fedfeb81d88957","7778b953c988957","5f9f2e64c788957","dcbec5006d88957","92379eaa2288957","e4b480f1c488957","8e0899a40088957","7cd0129c6f88957","361876dd6388957","0bb911f50b88957");
$r=rand(0,9);


 $challenge=explode('"',$new->solve($url_solve))[5];
 echo $new->msg("save image").$new->jeda().$new->rm();
 $open=fopen('img.jpg', 'w');
   fwrite($open,$new->challenge($challenge));
   fclose($open);
   echo $new->msg("crop image").$new->jeda().$new->rm();
   shell_exec("2>/dev/null convert img.jpg -pointsize 75% -threshold 65% -gravity Center -crop 350x142+0+10 +repage foto.png");
   echo $new->msg("read text").$new->jeda().$new->rm();
$hasil=json_decode(shell_exec('curl --silent -H "apikey:'.$api[$r].'" --form "file=@foto.png" --form "language=eng" --form "ocrengine=2" --form "isOverlayRequired=true" --form "iscreatesearchablepdf=false" https://api.ocr.space/Parse/Image'))->ParsedResults[0]->ParsedText;
echo $new->msg("replace image").$new->jeda().$new->rm();
$hasil=str_replace("\n"," ",$hasil);
  if($hasil<=null){
   goto ulang;
  }else{
   echo "captcha: ".$hasil;
   sleep(1);
   echo $new->rm();
  }
echo $new->msg("done all").$new->jeda().$new->rm();
   $claim=$new->ajax($token,$challenge,$hasil);
   
   $stat=json_decode($claim)->status;
   if($stat=="200"){
    $balance=$new->pars('<div class="text-primary"><b>','</b></div></div>',1,$new->page());
    $roll=json_decode($claim)->number;
    $reward=json_decode($claim)->reward;
    echo "\n{$green2}status: {$putih2}Success{$yellow}.{$green2}Lucky Number: {$putih2}{$roll}{$yellow}.{$green2}Reward: {$putih2}{$reward} Bits{$yellow}.{$green2}Balance: {$putih2}{$balance}\n";
    echo $new->timer(600);
   }else{
    echo $new->msg("retrying bypass").$new->jeda().$new->rm();
   }
   }
  
 

