<?php

$useragent = "#####";

$cookie = "#####";
$apikey = "######";

?>