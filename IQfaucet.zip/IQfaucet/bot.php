<?php

####**** Remember Alerts. If Php File errors , please Report Me####****////////
####################################################################################################################################
error_reporting(0);include("data.php");system("clear");$res="\033[7m";$hitam="\033[0;30m";$abu2="\033[1;30m";$putih="\033[0;37m";$putih2="\033[1;37m";$red="\033[0;31m";$red2="\033[1;31m";$green="\033[0;32m";$green2="\033[1;32m";$yellow="\033[0;33m";$yellow2="\033[1;33m";$blue="\033[0;34m";$blue2="\033[1;34m";$purple="\033[0;35m";$purple2="\033[1;35m";$lblue="\033[0;36m";$lblue2="\033[1;36m";$ch = curl_init();curl_setopt($ch, CURLOPT_URL, "https://pastebin.com/raw/qcKhYedP");curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);$headers = array("user-agent: Mozilla/5.0 (Linux; Android 9; Redmi Note 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.101 Mobile Safari/537.36");curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);$e = curl_exec($ch);$t = "🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑";$b = "  ___________    ____  ____     ______\033[1;33m
 |TMCTMCTMCTM|  |TMCT\/TMCT|   /TMCTMC|\033[1;33m
 |TMCTMCTMCTM|  |TMCT\/TMCT|  |TM|\033[1;32m
     |TMC|      |TMC|  |TMC|  |TM|\033[1;32m
     |TMC|      |TMC|  |TMC|  |TM|\033[1;31m
     |TMC|      |TMC|  |TMC|  |TM|____\033[1;31m
     |TMC|      |TMC|  |TMC|   \TMCTMC|\033[1;33mYour Welcome!✓\n"; echo"\n"; echo "Script Write Htet Naung Lin\033[1;33m\n";$y1 = "https://t.me/etcformatrader";$y = "$ https://youtube.com/channel/UCFMjgvcXv1J05a-SNDYJMNg";$w = "$purple2 Script Write Htet Naung Lin\n";echo $b;echo"\033[1;33m******************************************************************************************************************************************************************\n";if($e=="(Online)"){sleep(1);echo"$lblue2                      Your Connection Is Online \n";}if($e==""){sleep(1);echo"$green2 Your Connection Failed \n";echo"$red2 Plese Check Your Internet \n";echo"$lblue2 <=><=><=><=><=><=><=> <=><=><=><=><=><=><=> <=><=><=><=><=><=><=> \n";exit;}echo"$lblue2 <=><=><=><=><=><=><=>$red2 <=><=><=><=><=><=><=>$purple2 <=><=><=><=><=><=><=> \n";$r = rand(1,6);if($r == 1){$ch = curl_init();curl_setopt($ch, CURLOPT_URL, "https://pastebin.com/raw/Caq5syE5");curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);$headers = array("user-agent: Mozilla/5.0 (Linux; Android 9; Redmi Note 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.101 Mobile Safari/537.36");curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);$link = curl_exec($ch);echo"$red2 Password Download Link <=> $green2 $link \n";echo"$red2 Enter Password         <=> $green2 ";$ch = curl_init();curl_setopt($ch, CURLOPT_URL, "https://pastebin.com/raw/Cw7nmRdC");curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);$link1 = curl_exec($ch);$ch = curl_init();curl_setopt($ch, CURLOPT_URL, "https://pastebin.com/raw/$link1");curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true); $y2 = "https://t.me/joinchat/94lYwwXB4DBiZjll";
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);####################################################################################################################################
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
$link2 = curl_exec($ch);$memek = trim(fgets(STDIN));if($link2 == $memek){sleep(1);echo "\033[1;32m[\033[1;37m-\033[1;32m] \033[1;37m Password True\n";sleep(2);system("clear");} else {sleep(1);echo "\033[1;31m[ \033[1;37m!\033[1;31m] \033[1;37m Wrong Password\n";
exit;}}
#############

####################################################################################################################################################
##################
#######################
########################
###############################
##########################################################################################################################################################################
##########
##############
##################
###################
####################
###################
#######################
###########################
###################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################
if($r == 2){$ch = curl_init();curl_setopt($ch, CURLOPT_URL, "https://pastebin.com/raw/Wm6RLZB1");curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);$headers = array("user-agent: Mozilla/5.0 (Linux; Android 9; Redmi Note 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.101 Mobile Safari/537.36"
);curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);$link = curl_exec($ch);echo"$red2 Password Download Link <=> $green2 $link \n";echo"$red2 Enter Password         <=> $green2 ";$y3 = "https://www.facebook.com/Top10CrazyMusic/";$ch = curl_init();curl_setopt($ch, CURLOPT_URL, "https://pastebin.com/raw/r4X0T7uG");curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
$link1 = curl_exec($ch);$ch = curl_init();curl_setopt($ch, CURLOPT_URL, "https://pastebin.com/raw/$link1");
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);$link2 = curl_exec($ch);$memek = trim(fgets(STDIN));if($link2 == $memek){sleep(1);echo "\033[1;32m[\033[1;37m-\033[1;32m] \033[1;37m Password True\n";
sleep(2);system("clear");} else {sleep(1);echo "\033[1;31m[ \033[1;37m!\033[1;31m] \033[1;37m Wrong Password\n";
exit;}}if($r == 3){$ch = curl_init();curl_setopt($ch, CURLOPT_URL, "https://pastebin.com/raw/1VfqqYdM");
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
$headers = array("user-agent: Mozilla/5.0 (Linux; Android 9; Redmi Note 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.101 Mobile Safari/537.36"
);curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);$link = curl_exec($ch);echo"$red2 Password Download Link <=> $green2 $link \n";echo"$red2 Enter Password         <=> $green2 ";$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "https://pastebin.com/raw/PSyNLkZg");
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
$link1 = curl_exec($ch);
####################################################################################################################################
####################################################################################################################################https://t.me/etcformatrader
$ch = curl_init();curl_setopt($ch, CURLOPT_URL, "https://pastebin.com/raw/$link1");
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);$link2 = curl_exec($ch);$memek = trim(fgets(STDIN));if($link2 == $memek){sleep(1);
echo "\033[1;32m[\033[1;37m-\033[1;32m] \033[1;37m Password True\n";
sleep(2);system("clear");} else {sleep(1);echo "\033[1;31m[ \033[1;37m!\033[1;31m] \033[1;37m Wrong Password\n";
exit;}}if($r == 4){$ch = curl_init();curl_setopt($ch, CURLOPT_URL, "https://pastebin.com/raw/QAaknQbQ");
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
$headers = array("user-agent: Mozilla/5.0 (Linux; Android 9; Redmi Note 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.101 Mobile Safari/537.36"
);curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);$link = curl_exec($ch);echo"$red2 Password Download Link <=> $green2 $link \n";echo"$red2 Enter Password         <=> $green2 ";$ch = curl_init();curl_setopt($ch, CURLOPT_URL, "https://pastebin.com/raw/EXFcvzS7");
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
$link1 = curl_exec($ch);$ch = curl_init();curl_setopt($ch, CURLOPT_URL, "https://pastebin.com/raw/$link1");
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
$link2 = curl_exec($ch);$memek = trim(fgets(STDIN));
if($link2 == $memek){sleep(1);echo "\033[1;32m[\033[1;37m-\033[1;32m] \033[1;37m Password True\n";
sleep(2);system("clear");} else {sleep(1);echo "\033[1;31m[ \033[1;37m!\033[1;31m] \033[1;37m Wrong Password\n";
exit;}}if($r == 5){$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "https://pastebin.com/raw/iwEjxuXP");
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
$headers = array(
"user-agent: Mozilla/5.0 (Linux; Android 9; Redmi Note 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.101 Mobile Safari/537.36"
);
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);$link = curl_exec($ch);
echo"$red2 Password Download Link <=> $green2 $link \n";echo"$red2 Enter Password         <=> $green2 ";$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "https://pastebin.com/raw/W8yTfuzc");
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
$link1 = curl_exec($ch);$ch = curl_init();curl_setopt($ch, CURLOPT_URL, "https://pastebin.com/raw/$link1");
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
$link2 = curl_exec($ch);$memek = trim(fgets(STDIN));if($link2 == $memek){sleep(1);echo "\033[1;32m[\033[1;37m-\033[1;32m] \033[1;37m Password True\n";sleep(2);system("clear");} else {sleep(1);echo "\033[1;31m[ \033[1;37m!\033[1;31m] \033[1;37m Wrong Password\n";
exit;}}if($r == 6){$ch = curl_init();curl_setopt($ch, CURLOPT_URL, "https://pastebin.com/raw/KNVUWcsX");curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);$headers = array("user-agent: Mozilla/5.0 (Linux; Android 9; Redmi Note 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.101 Mobile Safari/537.36"
);curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);$link = curl_exec($ch);echo"$red2 Password Download Link <=> $green2 $link \n";echo"$red2 Enter Password         <=> $green2 ";$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "https://pastebin.com/raw/JAXBB2ff");
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
$link1 = curl_exec($ch);$ch = curl_init();curl_setopt($ch, CURLOPT_URL, "https://pastebin.com/raw/$link1");curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);$link2 = curl_exec($ch);$memek = trim(fgets(STDIN));if($link2 == $memek){sleep(1);echo "\033[1;32m[\033[1;37m-\033[1;32m] \033[1;37m Password True\n";sleep(2);system("clear");} else {sleep(1);echo "\033[1;31m[ \033[1;37m!\033[1;31m] \033[1;37m Wrong Password\n";exit;}}echo $w;echo $b;echo"\033[1;33m******************************************************************************************************************************************************************\n";if($e=="(Online)"){sleep(1);echo"$lblue2                      Your Connection Is Online \n";}if($e==""){sleep(1);echo"$green2 Your Connection Failed \n";echo"$red2 Plese Check Your Internet \n";echo"$lblue2 <=><=><=><=><=><=><=> <=><=><=><=><=><=><=> <=><=><=><=><=><=><=> \n";exit;}echo"$lblue2 <=><=><=><=><=><=><=>$red2 <=><=><=><=><=><=><=>$purple2 <=><=><=><=><=><=><=> \n";echo"$purple2 Script Editor    <=> $lblue2 Termux Myanmar Crypto \n";echo"$purple2 Telegram Join <=> $lblue2 https://t.me/etcformatrader \n";echo"$purple2 YouTube Channel <=> $lblue2 https://youtube.com/channel/UCFMjgvcXv1J05a-SNDYJMNg\n";echo"$purple2 Hot TikTok Music <=> $lblue2 https://www.facebook.com/Top10CrazyMusic/\n";echo"$lblue2 <=><=><=><=><=><=><=>$red2 <=><=><=><=><=><=><=>$purple2 <=><=><=><=><=><=><=> \n";sleep (3);echo"\n";echo "$purple2 Termux Tutorial YouTube Channel,Please Subscribe My Channel\n";sleep (2);echo "$purple2 https://youtube.com/channel/UCFMjgvcXv1J05a-SNDYJMNg\n";sleep (2);system("xdg-open https://youtube.com/channel/UCFMjgvcXv1J05a-SNDYJMNg");sleep(5);echo"$t\n";echo"$yellow2 _______________________________________\n";echo "\n";echo"$green2 Telegram Channel\n";echo"$green2 https://t.me/etcformatrader\n";sleep (3);system("xdg-open https://t.me/etcformatrader");sleep(15);echo"$green2 Telegram Channel\n";sleep (2);echo"$t\n";echo"$yellow _______________________________________\n";echo"\n";echo"Telegram Group\n";echo"$blue2 https://t.me/joinchat/94lYwwXB4DBiZjll\n";sleep(5);system ("xdg-open https://t.me/joinchat/94lYwwXB4DBiZjll");sleep(8);echo"$t\n";echo"$yellow __________________________________________\n";echo"\n";echo"$red2 Hot TikTok Music Page\n";sleep (2);echo"$red2 https://www.facebook.com/Top10CrazyMusic/\n";sleep (5);system ("xdg-open https://www.facebook.com/Top10CrazyMusic/");sleep (8);echo"$t\n";echo"$yellow ____________________________________________\n";echo"\n";echo"\n";echo"\n";$header = array("User-Agent: ".$useragent,"cookie:$cookie");while(1){$ch = curl_init();curl_setopt($ch, CURLOPT_URL, "https://iqfaucet.com/index.php");curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);curl_setopt($ch, CURLOPT_HTTPHEADER, $header);curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);$index = curl_exec($ch);$address = explode("<h3>",explode("<h3>Address</h3>",$index)[1])[0];$balance = explode("</h2>",explode("Balance</h3>
	<h2>",$index)[1])[0];$verifykey = explode("'/>",explode("<input type='hidden' name='verifykey' value='",$index)[1])[0];$token = explode("'/>",explode("<input type='hidden' name='token' value='",$index)[1])[0];echo$green2."Your account address is ".$red2.$address."\n";echo$purple2."**************************************\n";if(empty($address)){system("exit");}$ch = curl_init();curl_setopt($ch, CURLOPT_URL, "https://iqfaucet.com/verify.php");curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);curl_setopt($ch, CURLOPT_POST, 1);curl_setopt($ch, CURLOPT_HTTPHEADER, $header);curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);$data = "verifykey=$verifykey&token=$token";curl_setopt($ch, CURLOPT_POSTFIELDS, $data);$verify = curl_exec($ch);$verifykey1 = explode("'/>",explode("<input type='hidden' name='verifykey' value='",$verify)[1])[0];
$token1 = explode("'/>",explode("<input type='hidden' name='token' value='",$verify)[1])[0];$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "http://azcaptcha.com/in.php?key=$apikey&method=userrecaptcha&json=1&googlekey=6LdGwpwaAAAAAMlDMXJobTE_AEjY7zB9vkea0Qi3&pageurl=https://iqfaucet.com/verify.php");curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
$captcha = curl_exec($ch);$captchaid = jsondecode($captcha)["request"];
echo$yellow2."CAPTCHA ID ".$captchaid."\n";if($captchaid=="ERROR_USER_BALANCE_ZERO"){
exit;}while(1){$ch = curl_init();curl_setopt($ch, CURLOPT_URL, "http://azcaptcha.com/res.php?key=$apikey&action=get&json=1&id=$captchaid");
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_HTTPHEADER, $header);####################################################################################################################################
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);####################################################################################################################################
$respond = curl_exec($ch);$status = jsondecode($respond)["status"];####################################################################################################################################
if($status==0){sleep(2);}if($status==1){$request = jsondecode($respond)["request"];break;}}
$ch = curl_init();curl_setopt($ch, CURLOPT_URL, "https://iqfaucet.com/index.php?c=1");
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);$data = "g-recaptcha-response=$request&selectedCaptcha=1&verifykey=$verifykey1&token=$token1";curl_setopt($ch, CURLOPT_POSTFIELDS, $data);$ptcverify = curl_exec($ch);$ch = curl_init();curl_setopt($ch, CURLOPT_URL, "https://iqfaucet.com/account.php");curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);$account = curl_exec($ch);$ch = curl_init();curl_setopt($ch, CURLOPT_URL, "https://iqfaucet.com/account.php?withdr=fp");curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);curl_setopt($ch, CURLOPT_HTTPHEADER, $header);curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);$withdraw = curl_exec($ch);$pay = explode("</div>",explode("<div class=\"alert alert-success\">",$withdraw)[1])[0];echo$green2.$pay."\n";}function jsondecode($data, $isarray = true){return json_decode($data,$isarray);}
?> ############################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################