<?php

$useragent = "xxxx";

$cookie = "xxxx";

$solve = "xxxx";