<?php

//                __                            _
//               / _| ___  _ __ _ __   ___  ___(_) __ _
//              | |_ / _ \| '__| '_ \ / _ \/ __| |/ _` |
//              |  _| (_) | |  | | | |  __/\__ \ | (_| |
//              |_|  \___/|_|  |_| |_|\___||___/_|\__,_|
//              Config Files - https://www.fornesia.com
//

// user-agent
$agent = 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:89.0) Gecko/20100101 Firefox/89.0';

// setting password web - leave dafault or change
$paswd = 'bitdigi';

// Timer Reset Wallet end // Default = 30
$timereset = '30';