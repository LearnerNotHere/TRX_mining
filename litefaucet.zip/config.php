<?php




$useragent = "xxxxxx";


$cookie = "xxxxxxx";














