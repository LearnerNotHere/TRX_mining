<?php
$res="\033[0m";
$abu2="\033[1;30m";
$putih="\033[0;37m";
$putih2="\033[1;37m";
$red="\033[0;31m";
$red2="\033[1;31m";
$green="\033[0;32m";
$green2="\033[1;32m";
$yellow="\033[0;33m";
$yellow2="\033[1;33m";
$blue="\033[0;34m";
$blue2="\033[1;34m";
$purple="\033[0;35m";
$purple2="\033[1;35m";
error_reporting(0);
system("clear");
function pars($awalan,$akhiran,$res){
	$a=explode($awalan,$res);
	$b=explode($akhiran,$a[1]);

	return $b[0];
}
   function dash(){
     return curl("https://coinpot.in/dashboard");
}
   function page(){
     return curl("https://coinpot.in/ptc");
}
   function view($numb){
     return curl("https://coinpot.in/ptc/view/{$numb}");
}
   function verify($numb,$hasil,$csrf,$token){
     return curl("https://coinpot.in/ptc/verify/{$numb}","captcha=mooncaptchav2&answer={$hasil}&csrf_token_name={$csrf}&token={$token}");
}

if(file_exists("cookie")){
$cookie=file_get_contents("cookie");
}else{
echo "\nmasukan cookie: ";
 $cookie=trim(fgets(STDIN));
file_put_contents("cookie",$cookie);
}
system("clear");
   function capx($numb,$hasil,$csrf,$token){
        global $cookie;
	  $head=["Host: coinpot.in","content-type: application/x-www-form-urlencoded","user-agent: Mozilla/5.0 (Linux; Android 10; CPH1819 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/81.0.4044.138 Mobile Safari/537.36","accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng;q=0.8,application/signed-exchange;v=b3;q=0.9","referer: https://coinpot.in/ptc/view/{$numb}","cookie: {$cookie}"];
          $ch = curl_init();
          curl_setopt($ch,CURLOPT_URL, "https://coinpot.in/ptc/verify/{$numb}");
          curl_setopt($ch, CURLOPT_HEADER, true);
          curl_setopt($ch, CURLOPT_HTTPHEADER,$head);
          curl_setopt($ch, CURLOPT_RETURNTRANSFER,true);
          curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
          curl_setopt($ch, CURLOPT_MAXREDIRS, 20);
          curl_setopt($ch,CURLOPT_POSTFIELDS, "captcha=mooncaptchav2&answer={$hasil}&csrf_token_name={$csrf}&token={$token}");
          return curl_exec($ch);}
	  function curl($url, $post=0){
	  global $cookie;
          $ch = curl_init();
          curl_setopt($ch, CURLOPT_URL, $url);
          curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
          curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
          curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
          curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
          curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 30);
          curl_setopt($ch, CURLOPT_TIMEOUT, 60);
          if($post){
          curl_setopt($ch, CURLOPT_POST, true);
          curl_setopt($ch, CURLOPT_POSTFIELDS, $post);}
       	  $headers=array();
	  $headers[]="Host: coinpot.in";
	  $headers[]="accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9";
	  $headers[]="User-Agent: Mozilla/5.0 (Linux; Android 10; CPH1819 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/81.0.4044.138 Mobile Safari/537.36";
	  $headers[]="cookie: {$cookie}";
	  $headers[]="accept-language: id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7";
      	curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
      return curl_exec($ch);
   }
function msg($str){
echo $str;
}
function jeda(){
return usleep(500000);
}
function rm(){
return "\r                                 \r";
}
function tmr($tmr){
     $timr=time()+$tmr;
      while(true):
      echo "\r                       \r";
      $res = $timr-time();
      if($res < 1){
break;
  }
      echo date('H:i:s',$res);
      sleep(1);
      endwhile;
  }
function timer($tmr){
     $timr=time()+$tmr;
      while(true):
      echo "\r                       \r";
      $res = $timr-time();
      if($res < 1){
break;
  }
      echo "berburu ptc🧐 ".date('H:i:s',$res);
      sleep(1);
      endwhile;
  }
$nama=pars("siteUserFullName: '","<vie",dash());
$balance=pars('<h2 class="title">','</h2>',dash());


echo $blue."\n╔══════════════════════════╗";
echo $blue."\n║".$putih."██████████████████████████".$blue."║";
echo $blue."\n║".$putih."█".$blue."╔═════╗".$putih."███████████████⊙██".$blue."║";
echo $blue."\n║".$putih."█".$blue."║".$yellow."NOKIA".$blue."║".$putih."██████████████████".$blue."║".$putih." = = = = = = = = = = = = = = = =";
echo $blue."\n║".$putih."█".$blue."╚═════╝".$putih."██████████████████".$blue."║".$putih2." [!] CREATOR : MRs.M4JOR.exe";
echo $blue."\n║".$putih."██████████████████████████".$blue."║".$putih2." [!] WHATSAPP : 081327753909";
echo $blue."\n║".$putih."█".$blue."╔══════════════════════╗".$putih."█".$blue."║ ".$putih2."[!] JOIN GRUP : t.me/panggilmajor";
echo $blue."\n║".$putih."█".$blue."║".$yellow."XL".$abu2."▒▒▒▒▒▒▒▒▒▒".$putih2."📶4G".$abu2."▒▒".$putih2."100%".$blue."║".$putih."█".$blue."║ ".$putih2."[#] VERSI : 2.0";
echo $blue."\n║".$putih."█".$blue."║".$abu2."▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒".$blue."║".$putih."█".$blue."║".$putih." = = = = = = = = = = = = = = = =";
echo $blue."\n║".$putih."█".$blue."║".$abu2."▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒".$blue."║".$putih."█".$blue."║".$putih." = = = = = = = = = = = = = = = =";
echo $blue."\n║".$putih."█".$blue."║".$putih2."WELCOME TO SCRIPT ".$abu2."▒▒▒▒".$blue."║".$putih."█".$blue."║".$red." [!] warning !!";
echo $blue."\n║".$putih."█".$blue."║".$abu2."▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒".$blue."║".$putih."█".$blue."║".$yellow." [-] ini adalah program ilegal";
echo $blue."\n║".$putih."█".$blue."║".$putih2."BY MR.MAJOR  ".$abu2."▒▒▒▒▒▒▒▒▒".$blue."║".$putih."█".$blue."║".$yellow." [-] https://saweria.co/Mrmajor";
echo $blue."\n║".$putih."█".$blue."║".$abu2."▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒".$blue."║".$putih."█".$blue."║".$putih." = = = = = = = = = = = = = = = =";
echo $blue."\n║".$putih."█".$blue."║".$putih2."----------".$abu2."▒▒▒▒▒▒▒▒▒▒▒▒".$blue."║".$putih."█".$blue."║";
echo $blue."\n║".$putih."█".$blue."║".$abu2."▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒".$blue."║".$putih."█".$blue."║".$green2." [#] SCRIPT: coinpot.in";
echo $blue."\n║".$putih."█".$blue."║".$abu2."▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒".$blue."║".$putih."█".$blue."║";
echo $blue."\n║".$putih."█".$blue."║".$abu2."▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒".$blue."║".$putih."█".$blue."║".$putih." = = = = = = = = = = = = = = = =";
echo $blue."\n║".$putih."█".$blue."║".$abu2."▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒".$blue."║".$putih."█".$blue."║".$green2." [#] nickname {$putih2}={$red2}> ".$putih2.$nama;
echo $blue."\n║".$putih."█".$blue."║".$abu2."▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒".$blue."║".$putih."█".$blue."║".$green2." [$] balance {$putih2} ={$red2}> ".$putih2.$balance;
echo $blue."\n║".$putih."█".$blue."║".$abu2."▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒".$blue."║".$putih."█".$blue."║".$putih." = = = = = = = = = = = = = = = =";
echo $blue."\n║".$putih."█".$blue."║".$abu2."▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒".$blue."║".$putih."█".$blue."║";
echo $blue."\n║".$putih."█".$blue."║".$abu2."▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒".$blue."║".$putih."█".$blue."║";
echo $blue."\n║".$putih."█".$blue."║".$putih2."KEMBALI".$abu2."▒▒▒▒▒▒▒▒▒▒".$putih2."PILIH".$blue."║".$putih."█".$blue."║";
echo $blue."\n║".$putih."█".$blue."╚══════════════════════╝".$putih."█".$blue."║";
echo $blue."\n║".$putih."██████████████████████████".$blue."║";
echo $blue."\n║".$putih."███▤▤▤▤▤██▧▧▧▧▧▧██▤▤▤▤▤███".$blue."║";
echo $blue."\n║".$putih."██████████████████████████".$blue."║";
echo $blue."\n╚══════════════════════════╝\n";

echo msg("gak subrek gay").jeda();
echo rm();

while(true){
ulang:
$page_ptc=page();
$view_id=pars('https://coinpot.in/ptc/view/',"'",$page_ptc);
$moonv2=['1','3','4'];
$ray=count($moonv2);
$r=rand(0,$ray-1);
$hasil=$moonv2[$r];
$timer=pars('<span class="bg-purple">Time: ','sec</span>',$page_ptc);
echo msg("view ptc {$timer} seconds").jeda().rm();
$view=view($view_id);
if($timer<=null){
}
else{
echo tmr($timer);
}
echo msg("success view ptc").jeda().rm();
echo msg("get csrf token").jeda().rm();
$csrf=pars('name="csrf_token_name" value="','">',$view);
echo msg("ambil token").jeda().rm();
$token=pars('name="token" value="','">',$view);

$blc_awal=pars('<h2 class="title">','</h2>',dash());

echo $putih2.msg("bypass 1 dari 5").jeda().rm();
$claim=capx($view_id,0,$csrf,$token);
echo msg("bypass 2 dari 5").jeda().rm();
$claim=capx($view_id,1,$csrf,$token);
echo msg("bypass 3 dari 5").jeda().rm();
$claim=capx($view_id,2,$csrf,$token);
echo msg("bypass 4 dari 5").jeda().rm();
$claim=capx($view_id,3,$csrf,$token);
echo msg("bypass 5 dari 5").jeda().rm();
$claim=capx($view_id,4,$csrf,$token);
echo $green2.msg("done all").jeda().rm();
$blc_akhir=pars('<h2 class="title">','</h2>',dash());
$sisa=pars('<h2 class="title">','</h2>',page());
if($sisa<=null){
echo "{$red}tidak ada ptc";
jeda().rm();
   goto ulang;
}else{
}
if($sisa<"1"){
echo timer(100);
}else{
}
if($blc_awal<=null){
goto ulang;
}elseif($blc_akhir<=null){
goto ulang;
}else{
}
if($blc_awal<$blc_akhir){
$claimed=$blc_akhir-$blc_awal;
echo "\n{$green2}success {$putih2}{$claimed} {$green2}coins has been added {$yellow2}Balance: {$putih2}{$blc_akhir}{$yellow2} sisa ptc:{$putih2} {$sisa}\n";
}else{
echo msg("{$red}retrying bypass").jeda().rm();
}
}
