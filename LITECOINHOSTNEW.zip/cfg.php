<?php
//INPUT WALLET ADDRES DARI FAUCETPAY

$btc = "xxxx";
$eth = "xxxx";
$bnb = "xxxx";
$fey = "xxxx";
$bch = "xxxx";
$usdt = "xxxx";
$zec = "xxxx";
$doge = "xxxx";
$dash = "xxxx";
$dgb = "xxxx";
$trx = "xxxx";
$sol = "xxxx";
$stop = "stop";

//JANGAN DI APA APAIN
$web_btc = "https://litecoin.host/0/btc/";
$web_eth = "https://litecoin.host/0/eth/";
$web_bch = "https://litecoin.host/0/bch/";
$web_doge = "https://litecoin.host/0/doge/";
$web_dash = "https://litecoin.host/0/dash/";
$web_dgb = "https://litecoin.host/0/dgb/";
$web_trx = "https://litecoin.host/0/trx/";
$web_usdt = "https://litecoin.host/0/usdt/";
$web_fey = "https://litecoin.host/0/fey/";
$web_bnb = "https://litecoin.host/0/bnb/";
$web_zec = "https://litecoin.host/0/zec/";
$web_sol = "https://litecoin.host/0/sol/";
$stop = "stop";
