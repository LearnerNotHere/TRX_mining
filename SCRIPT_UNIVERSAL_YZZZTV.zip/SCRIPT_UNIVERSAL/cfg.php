<?php

// ISI SEMUA DATA DENGAN BENAR
// JANGAN SKIP VIDEO SUPAYA GAK GAGAL

//user-agent
$user = "xxxx";

//cookie
$cookie = "xxxx";

//timer-claim-dalam-satuan-detik
$tmr = "xxx";

//url-target-claim
$webtarget = "xxxx";
