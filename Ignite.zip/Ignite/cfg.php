<?php

# User-Agent
$uagent = "xxx";

# Cookie
$cookie = "xxx";

# Url Solve Media
$urlsolve = "xxx";
