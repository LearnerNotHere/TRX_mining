<?php

# Your User-Agent 👇

$uag = "xxxxxxxxxx";


# Your Cookie 👇

$cook = 'xxxxxxxxx';


# 1 Bitcoin
# 2 Ethereum
# 4 Dogecoin
# 5 Litecoin
# 6 Bitcoin Cash
# 7 Dash
# 8 DigiByte
# 9 Tron
# 10 Tether
# 11 Feyorra

$coin = "1";



?>
