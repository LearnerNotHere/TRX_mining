<?php

#USERAGENT
$useragent = "xxxxxxxxxx";

#COOKIE
$cookie = 'xxxxxxxx';

?>