<?php

//AMBIL SMUA DATA DI HALAMAN :
//https://ryzex.net/dashboard/bonus
$useragent = "xxxx";

$cookie = "xxxx";

$xsrfTOKEN = "xxxx";