<?php

# Enter Address

$address = "xxx";


# Select Currency

$doge = "dogecoin";
$lite = "litecoin";
$trx = "tron";
$bnb = "binancecoin";
$eth = "ethereum";
$bch = "bitcoin-cash";
$dgb = "digibyte";
$dash = "dash";
$zec = "zcash";
$tht = "tether";
$fey = "feyorra";

$currency = "xxx";