<?php

$useragent = "xxxx";

$cookie = "xxxx";

//your faucetpay email
$fp = "xxxx";

//select coin auto wd (LTC:1/DOGE:2/FEY:3)
$coin = "x";

//autowd minimum 10
$set = "xx";