<?php

$cookie = "PHPSESSID=t1h9hrihreg6ka4hspcdkefv57;wassup_screen_res904f45c2543499512c24129035ab79f0=450%20x%20800;wassup904f45c2543499512c24129035ab79f0=MGJfNWJjNmExMTgwMTI3NGNjODE5NzNmZjg5YTUxYjdiZTkjIzE2Mzc1NTUzNTYjIzQ1MCB4IDgwMCMjMTAuMjQ0LjExLjEjIzEwLjI0NC4xMS4xIyM%253D;__gads=ID=b3fcfe5c829da30c-22b75e5b34cf0046:T=1637552658:RT=1637552658:S=ALNI_MaKJv8pAAMbM5pu_m0-4y9O1Q7X9w;dom3ic8zudi28v8lr6fgphwffqoz0j6c=d2a3284f-00f5-4b4c-a0ad-d463f7d43b9c%3A2%3A1;prefetchAd_4648903=true;address=qzxj6lhh4auudhhkkcxvgqzr2mu3vs4vyvyxuymujx";

$url_solve = "https://api-secure.solvemedia.com/papi/_challenge.js?k=CQxN5NMVQDLellX1B00r1vFRb.Ql9aEq;f=_ACPuzzleUtil.callbacks%5B0%5D;l=en;t=img;s=standard;c=js,h5c,h5ct,svg,h5v,v/h264,v/webm,h5a,a/mp3,a/ogg,ua/chrome,ua/chrome76,os/android,os/android9,fwv/Be-Pbw.mfwi4,cms/wordpress,jslib/jquery,htmlplus;am=7CmWZTtdi0Xpx-ARO12LRQ;ca=script;ts=1637542666;ct=1637552657;th=white;r=0.6241078093969159";

$wallet = "qzxj6lhh4auudhhkkcxvgqzr2mu3vs4vyvyxuymujx";

