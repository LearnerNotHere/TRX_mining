<?php
date_default_timezone_set("Asia/Jakarta");

$green = "\e[1;32m";
$blockglow = "\033[102m";
$blue = "\e[1;34m";
$blockblue = "\033[104m";
$red = "\e[1;31m";
$blockred = "\033[101m";
$blockpink = "\033[105m";
$white = "\33[37;1m";
$blockwhite = "\033[107m";
$yellow = "\e[1;33m";
$blockyellow = "\033[103m";
$cyan = "\e[1;36m";
$blockcyan = "\033[106m";
$purple = "\e[1;35m";
$gray = "\e[1;30m";
$blockgray = "\033[100m";
$end = "\033[0m";

include('cfg.php');
system('clear');
sleep(1);
//error_reporting(0);

function pembukaan(){
$green = "\e[1;32m";
$blue = "\e[1;34m";
$red = "\e[1;31m";
$white = "\33[37;1m";
$yellow = "\e[1;33m";
$cyan = "\e[1;36m";
$purple = "\e[1;35m";
$gray = "\e[1;30m"; 
echo$cyan."Welcome to".$purple." my Party xD\n";
sleep(2);
echo$green."Please subscribe my ".$red."YouTube".$green." channel".$white.":)\n";
sleep(3);
system('termux-open-url https://youtube.com/channel/UCIpifcDEHIaf4_4DXZyP9Iw');
sleep(10);
echo$yellow."Thanks ".$red."for ".$cyan."subscribe\n";
sleep(4);
system('clear');
}

function banner0(){
$cyan = "\e[1;36m";
echo "\n";
echo$cyan."   ___        ___                __                   \n";
echo$cyan."  / _ \____  / _ | ______ _  ___/ /________  ___ ___ _\n";
echo$cyan." / // / __/ / __ |/ __/  ' \(_-/ __/ __/ _ \/ _ / _ `/\n";
echo$cyan."/____/_/   /_/ |_/_/ /_/_/_/___\__/_/  \___/_//_\_, / \n";
echo$cyan."                                               /___/\n";
//sleep(1);
system('clear');
}

function banner(){
$cyan = "\e[1;36m";

echo "\n";
echo$cyan."   ___        ___                __                   \n";
echo$cyan."  / _ \____  / _ | ______ _  ___/ /________  ___ ___ _\n";
echo$cyan." / // / __/ / __ |/ __/  ' \(_-/ __/ __/ _ \/ _ / _ `/\n";
echo$cyan."/____/_/   /_/ |_/_/ /_/_/_/___\__/_/  \___/_//_\_, / \n";
echo$cyan."                                               /___/\n";
}


function strip(){
$green = "\e[1;32m";
$blue = "\e[1;34m";
$red = "\e[1;31m";
$white = "\33[37;1m";
$yellow = "\e[1;33m";
$cyan = "\e[1;36m";
$purple = "\e[1;35m";
$gray = "\e[1;30m";

echo$red."  ◼".$green."◼◼".$blue."◼◼".$white."◼◼".$yellow."◼◼".$cyan."◼◼".$purple."◼◼".$gray."◼◼".$red."◼◼".$green."◼◼".$blue."◼◼".$white."◼◼".$yellow."◼◼".$cyan."◼◼".$purple."◼◼".$gray."◼◼".$red."◼◼".$green."◼◼".$blue."◼◼".$white."◼◼".$yellow."◼◼".$cyan."◼◼".$purple."◼◼".$gray."◼◼".$green."◼◼".$red."◼\n";
}

function strip2(){
$green = "\e[1;32m";
$blue = "\e[1;34m";
$red = "\e[1;31m";
$white = "\33[37;1m";
$yellow = "\e[1;33m";
$cyan = "\e[1;36m";
$purple = "\e[1;35m";
$gray = "\e[1;30m";
$blockglow = "\033[102m";
$end = "\033[0m";
$strip2 = str_repeat($red."◼",56);
echo $strip2."\n";

}

function sruput(){
include('cfg.php');

$cyan = "\e[1;36m";
$white = "\33[37;1m";

echo$white." Coded By       : ".$cyan."Dr Armstrong\n";
echo$white." My Suhu        : ".$cyan."Mr.J\n";
echo$white." Chanel YouTube : ".$cyan."shorturl.at/tBEF5(Dr Armstrong)\n";
echo$white." Chenel Telegram: ".$cyan."https://t.me/DrArmstronga\n";
echo$white." Grub Diskusi   : ".$cyan."https://t.me/joinchat/BWZXWUGEe902NGM1\n";
}

function note(){
$cyan = "\e[1;36m";
echo$cyan."jangan lupa subscribe Dr Armstrong dan join Chenel    Telegram Dr Armstrong link diatas tanpa iklan\n";
}

function Get($url, $ua){
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($ch, CURLOPT_ENCODING, "");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "GET");
curl_setopt($ch, CURLOPT_HTTPHEADER, $ua);
curl_setopt($ch, CURLOPT_TIMEOUT, 60);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
$result = curl_exec($ch);
curl_close($ch);
return $result; 
sleep(1);
}

function Opt($url, $ua){
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($ch, CURLOPT_ENCODING, "");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "OPTIONS");
curl_setopt($ch, CURLOPT_HTTPHEADER, $ua);
curl_setopt($ch, CURLOPT_TIMEOUT, 60);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
$result = curl_exec($ch);
curl_close($ch);
return $result; 
sleep(1);
}

function Post($url, $ua, $data){
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_HTTPHEADER, $ua);
curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
curl_setopt($ch, CURLOPT_COOKIEJAR, "cookie.txt");
curl_setopt($ch, CURLOPT_COOKIEFILE, "cookie.txt");
$result = curl_exec($ch);
curl_close($ch);
return $result; 
}

pembukaan();
banner0();
banner();
strip2();
sruput();
note();
strip2();

//DASHBOARD
$url = "https://faucetsiteindonesia.web.id/office/dashboard";
$ua = ["user-agent: ".$useragent,
"cookie: ".$cookie];
$d = Get($url,$ua);
$e = "
                      ";
  $one = explode('<h5 class="font-weight-bolder mb-0">'.$e,$d);
  $two = explode(' TRX',$one[1]);
  $bal = "$two[0]";
$sp = "
                      ";
                      $one = explode('<h5 class="font-weight-bolder mb-0">'.$sp,$d);
                      $two = explode(' ACT',$one[2]);
                      $act0 = "$two[0]";
                      $one = explode('<h5 class="font-weight-bolder mb-0">'.$sp,$d);
                      $two = explode(' Game',$one[4]);
                      $gt = "$two[0]";  
echo$cyan."Your Balance   : ".$yellow.$bal.$red." TRX\n";
echo$cyan."Your ACT       : ".$yellow.$act0.$red." ACT\n";
echo$cyan."Your GameToken : ".$yellow.$gt.$red." Token\n";
strip2();
echo$white."What do you want?\n";
echo$red."[".$yellow."1".$red."]".$white."Auto Play Game\n";
echo$red."[".$yellow."2".$red."]".$white."Auto Claim Faucet\n";
$pilih = readline($white."Your answer : ".$yellow);
sleep(1);
strip2();
switch($pilih){
case 1;
echo$yellow."\r Auto Play Game started...    \r";
sleep(1);
while(true){
$url = "https://faucetsiteindonesia.web.id/office/dashboard";
$ua = ["user-agent: ".$useragent,
"cookie: ".$cookie];
$d = Get($url,$ua);
$e = "
                      ";
                      $one = explode('<h5 class="font-weight-bolder mb-0">'.$sp,$d);
                      $two = explode(' Game',$one[4]);
                      $gt = "$two[0]";  

if($gt == "0"){
echo$red."Not enough Game Token!\n\n\n";
exit;
}else{

//PLAY-GAME
$url = "https://faucetsiteindonesia.web.id/office/game";
$ua = ["user-agent: ".$useragent,
"cookie: ".$cookie];
$g = Get($url,$ua);
$one = explode('<a href="https://faucetsiteindonesia.web.id/office/game?play=',$g);
$two = explode('" class',$one[1]);
$game1 = "$two[0]";
$one = explode('<a href="https://faucetsiteindonesia.web.id/office/game?play=',$g);
$two = explode('&',$one[1]);
$tit1 = "$two[0]";
$one = explode('<a href="https://faucetsiteindonesia.web.id/office/game?play=',$g);
$two = explode('" class',$one[2]);
$game2 = "$two[0]";
$one = explode('<a href="https://faucetsiteindonesia.web.id/office/game?play=',$g);
$two = explode('&',$one[2]);
$tit2 = "$two[0]";

echo$white."Please choose the game           \n";
echo$red."[".$yellow."1".$red."]".$white.$tit1."\n";
echo$red."[".$yellow."2".$red."]".$white.$tit2."\n";
$gm = readline($white."Your answer : ".$yellow);
sleep(1);
strip2();
switch($gm){
case 1;

$url = "https://faucetsiteindonesia.web.id/office/game?play=".$game1;
$ua = ["user-agent: ".$useragent,
"cookie: ".$cookie];
$g1 = Get($url,$ua);
$one = explode('api_arcade?key=',$g1);
$two = explode('";',$one[1]);
$aa = "$two[0]";
$one = explode('card-header mb-4">Earn ',$g1);
$two = explode(' TRX Every',$one[1]);
$rwd = "$two[0]";
$one = explode('TRX Every ',$g1);
$two = explode(' Seconds',$one[1]);
$tmr = "$two[0]";

while(true){
for($x=$tmr;$x>0;$x--){echo "\r \r";
echo$gray." Next claim in ".$red."[".$yellow.$x.$red."] ".$gray."seconds ☕🚬";
echo "\r \r";
sleep(1);}

$link = "https://faucetsiteindonesia.web.id/office/api_arcade?key=".$aa;
$data = "";
$gp1 = Post($link,$ua,$data);
$one = explode('{"status":"',$gp1);
$two = explode('"',$one[1]);
$r = "$two[0]";

echo$white."\r Status : ".$green.$r.", ".$rwd." TRX received!\r";

$url = "https://faucetsiteindonesia.web.id/office/dashboard";
$ua = ["user-agent: ".$useragent,
"cookie: ".$cookie];
$d = Get($url,$ua);
$e = "
                      ";
  $one = explode('<h5 class="font-weight-bolder mb-0">'.$e,$d);
  $two = explode(' TRX',$one[1]);
  $bal = "$two[0]";
$sp = "
                      ";
                      $one = explode('<h5 class="font-weight-bolder mb-0">'.$sp,$d);
                      $two = explode(' ACT',$one[2]);
                      $act0 = "$two[0]";
                      $one = explode('<h5 class="font-weight-bolder mb-0">'.$sp,$d);
                      $two = explode(' Game',$one[4]);
                      $gt = "$two[0]";  
echo$green."Update balance:".$white."->".$yellow.$bal.$red." TRX".$white."•".$yellow.$act0.$red." ACT".$white."•".$yellow.$gt.$red." GToken\n";

if($gt == "0"){
echo$red."Not enough Game Token!\n\n\n";
exit;
}else{
echo"";
}
}

case 2;
$url = "https://faucetsiteindonesia.web.id/office/game?play=".$game2;
$ua = ["user-agent: ".$useragent,
"cookie: ".$cookie];
$g2 = Get($url,$ua);
$one = explode('api_arcade?key=',$g2);
$two = explode('";',$one[1]);
$aa = "$two[0]";
$one = explode('card-header mb-4">Earn ',$g2);
$two = explode(' TRX Every',$one[1]);
$rwd = "$two[0]";
$one = explode('TRX Every ',$g2);
$two = explode(' Seconds',$one[1]);
$tmr = "$two[0]";

while(true){
for($x=$tmr;$x>0;$x--){echo "\r \r";
echo$gray." Next claim in ".$red."[".$yellow.$x.$red."] ".$gray."seconds ☕🚬";
echo "\r \r";
sleep(1);}

$link = "https://faucetsiteindonesia.web.id/office/api_arcade?key=".$aa;
$data = "";
$gp1 = Post($link,$ua,$data);
$one = explode('{"status":"',$gp1);
$two = explode('"',$one[1]);
$r = "$two[0]";

echo$white."\r Status : ".$green.$r.", ".$rwd." TRX received!\r";

$url = "https://faucetsiteindonesia.web.id/office/dashboard";
$ua = ["user-agent: ".$useragent,
"cookie: ".$cookie];
$d = Get($url,$ua);
$e = "
                      ";
  $one = explode('<h5 class="font-weight-bolder mb-0">'.$e,$d);
  $two = explode(' TRX',$one[1]);
  $bal = "$two[0]";
$sp = "
                      ";
                      $one = explode('<h5 class="font-weight-bolder mb-0">'.$sp,$d);
                      $two = explode(' ACT',$one[2]);
                      $act0 = "$two[0]";
                      $one = explode('<h5 class="font-weight-bolder mb-0">'.$sp,$d);
                      $two = explode(' Game',$one[4]);
                      $gt = "$two[0]";  
echo$green."Update balance:".$white."->".$yellow.$bal.$red." TRX".$white."•".$yellow.$act0.$red." ACT".$white."•".$yellow.$gt.$red." GToken\n";

if($gt == "0"){
echo$red."Not enough Game Token!\n\n\n";
exit;
}else{
echo"";
}
}
}
}
}

case 2;
echo$yellow."\r Auto Claim Faucet started...    \r";
sleep(1);
while(true){
//AUTOCLAIM
$url = "https://faucetsiteindonesia.web.id/office/auto_claim";
$ua = ["user-agent: ".$useragent,
"cookie: ".$cookie];
$ac = Get($url,$ua);
$one = explode('bg-gradient-primary">Your Have ',$ac);
$two = explode(' ACT</span>',$one[1]);
$act = "$two[0]";
$one = explode('var timeLeft = ',$ac);
$two = explode(';',$one[1]);
$tmr = "$two[0]";
$one = explode('name="_token" value="',$ac);
$two = explode('"></form>',$one[1]);
$tk = "$two[0]";

if($act > 2){
for($x=$tmr;$x>0;$x--){echo "\r \r";
echo$gray." Please wait ".$red."[".$yellow.$x.$red."] ".$gray."seconds ☕🚬";
echo "\r \r";
sleep(1);}

$link = "https://faucetsiteindonesia.web.id/office/auth/faucet/claim3";
$data = "_token=".$tk;
$cfg = Post($link, $ua, $data);

$url = "https://faucetsiteindonesia.web.id/office/auto_claim";
$ua = ["user-agent: ".$useragent,
"cookie: ".$cookie];
$a2 = Get($url, $ua);
$one = explode("alertify.success('",$a2);
$two = explode("');",$one[1]);
$msg = "$two[0]";

echo$green."\r ".$msg."                \r";

$url = "https://faucetsiteindonesia.web.id/office/dashboard";
$ua = ["user-agent: ".$useragent,
"cookie: ".$cookie];
$d = Get($url,$ua);
$e = "
                      ";
  $one = explode('<h5 class="font-weight-bolder mb-0">'.$e,$d);
  $two = explode(' TRX',$one[1]);
  $bal = "$two[0]";
$sp = "
                      ";
                      $one = explode('<h5 class="font-weight-bolder mb-0">'.$sp,$d);
                      $two = explode(' ACT',$one[2]);
                      $act0 = "$two[0]";
                      $one = explode('<h5 class="font-weight-bolder mb-0">'.$sp,$d);
                      $two = explode(' Game',$one[4]);
                      $gt = "$two[0]";  
                      
echo$green."Update balance:".$white."->".$yellow.$bal.$red." TRX".$white."•".$yellow.$act0.$red." ACT".$white."•".$yellow.$gt.$red." GToken\n";

}else{
echo$red."Claim Failed!\n";
echo$white."Not enough ACT!\n";
break;
}
}
}