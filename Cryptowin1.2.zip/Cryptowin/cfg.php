<?php



#token
$token = "";

#bitPTC
$bitPTC = "";
